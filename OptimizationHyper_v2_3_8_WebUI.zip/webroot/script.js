"use strict";

/* =====================================================
   OptimizationHyper Web UI
   Bridge kompatibel dengan KernelSU Manager & WebUI X (MMRL)
   ===================================================== */

const CONFIG_PATH = "/data/adb/modules/optimizationhyper/config.sh";
// oh_apply_thermal() sekarang tinggal di satu file (oh_functions.sh, dipakai
// bareng dengan service.sh) - jadi apply instan cuma perlu source ini,
// bukan nyalin ulang seluruh isi fungsinya sebagai string di sini. Ini
// mencegah 2 kopi logika sama beda sendiri (itu penyebab awal case
// "balance" kelewatan & tidak pernah ke-underclock).
const FUNCTIONS_PATH = "/data/adb/modules/optimizationhyper/oh_functions.sh";

/* ---------- Root exec bridge (KernelSU / WebUI X standard) ---------- */
function ksuExec(command, options = {}, timeoutMs = 20000) {
  return new Promise((resolve) => {
    if (typeof ksu === "undefined" || !ksu.exec) {
      resolve({ errno: -1, stdout: "", stderr: "no-bridge" });
      return;
    }
    const cbName = `exec_cb_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      delete window[cbName];
      resolve(result);
    };
    // Safety net: kalau native bridge tidak pernah manggil callback (root
    // shell macet, mis. swapoff nge-block di device RAM kecil), Promise ini
    // dulu nge-hang selamanya -> itulah yang bikin seluruh panel kelihatan
    // freeze pas Apply, tanpa cara recover selain force-close app manager.
    const timer = setTimeout(() => {
      finish({ errno: -1, stdout: "", stderr: "timeout" });
    }, timeoutMs);
    window[cbName] = (errno, stdout, stderr) => {
      finish({ errno, stdout: stdout || "", stderr: stderr || "" });
    };
    try {
      ksu.exec(command, JSON.stringify(options), cbName);
    } catch (e) {
      finish({ errno: -1, stdout: "", stderr: String(e) });
    }
  });
}

/* ---------- i18n ---------- */
const I18N = {
  title: "OptimizationHyper",
  subtitle: "System tuning panel",
  theme_dark: "🌙 Dark",
  theme_light: "☀️ Light",
  bridge_ok: "Root bridge connected",
  bridge_fail: "Root bridge not found — open via KernelSU Manager or WebUI X",
  section_features: "Module Features",
  section_status: "System Status",
  stat_ram: "RAM",
  section_governor: "CPU Governor",
  section_anim: "Animation Scale",
  feat_ram: "RAM Management",
  feat_ram_desc: "Limit background apps limit for more free RAM",
  feat_graphics: "Graphics & Display",
  feat_graphics_desc: "Disable dithering, tune EGL buffer count",
  feat_logging: "Disable Logging",
  feat_logging_desc: "Turn off unnecessary system logging & debugging",
  toggle_on: "On",
  toggle_off: "Off",
  governor_enable: "Manage governor",
  governor_locked_desc: "Controlled automatically by Thermal Profile",
  anim_enable: "Manage animation scale",
  btn_reload: "Reload",
  saving: "Applying...",
  saved: "Saved & applied",
  save_fail: "Failed to apply, check root access",
  footer: "by Yannnbarubelajar",
  loading: "Loading configuration...",
  section_device: "Device Info",
  dev_kernel: "Kernel",
  dev_model: "Device Model",
  dev_android: "Android Version",
  dev_fps: "Frame Rate",
  dev_temp: "Phone Temperature",
  dev_cpu_temp: "CPU Temperature",
  section_iosched: "I/O Scheduler",
  iosched_enable: "Manage I/O scheduler",
  iosched_scanning: "Scanning available schedulers...",
  iosched_none: "Not detected",
  section_thermal: "Thermal Profile",
  thermal_enable: "Enable thermal profile",
  thermal_desc: "Adjust CPU governor & max frequency per profile",
  thermal_powersave: "Powersave",
  thermal_balance: "Balance",
  thermal_performance: "Performance",
  thermal_little_performance: "Little Performance",
  section_render: "Rendering",
  render_enable: "Manage rendering backend",
  render_desc: "Choose HWUI / RenderEngine graphics backend",
  section_display: "Screen Resolution & DPI",
  display_current: "Current",
  display_enable: "Use custom resolution & DPI",
  display_res_ph: "width x height, e.g. 1080x2400",
  display_dpi_ph: "DPI, e.g. 420",
  display_reset: "Reset to Default",
  display_applied: "Applied",
  display_warn: "Warning: wrong resolution/DPI can make the screen look broken. Use \"Reset to Default\" to recover.",
};

function t(key) {
  return I18N[key] || key;
}

function applyI18n() {
  document.documentElement.lang = "en";
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.getAttribute("data-i18n"));
  });
  document.querySelectorAll("[data-i18n-ph]").forEach((el) => {
    el.setAttribute("placeholder", t(el.getAttribute("data-i18n-ph")));
  });
}

/* ---------- Theme (dark/light) ---------- */
let currentTheme = localStorage.getItem("oh_theme") || "dark";

function applyTheme() {
  document.documentElement.setAttribute("data-theme", currentTheme);
  document.querySelectorAll(".theme-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.theme === currentTheme);
  });
}

function setTheme(theme) {
  currentTheme = theme;
  localStorage.setItem("oh_theme", theme);
  applyTheme();
}

/* ---------- Config state ---------- */
const state = {
  FEATURE_RAM_MGMT: "1",
  FEATURE_GRAPHICS: "1",
  FEATURE_LOGGING: "1",
  FEATURE_GOVERNOR: "0",
  CPU_GOVERNOR: "schedutil",
  FEATURE_ANIM: "0",
  ANIM_SCALE: "1.0",
  FEATURE_IOSCHED: "0",
  IO_SCHEDULER: "",
  FEATURE_THERMAL: "0",
  THERMAL_PROFILE: "balance",
  FEATURE_RENDER: "0",
  RENDER_BACKEND: "skiagl",
  FEATURE_DISPLAY: "0",
  DISPLAY_RES: "",
  DISPLAY_DPI: "",
};

const GOVERNORS = ["schedutil", "performance", "powersave", "conservative", "sugov_ext"];
const ANIM_SCALES = ["0.0", "0.5", "1.0"];
const THERMAL_PROFILES = ["powersave", "balance", "performance", "little_performance"];
const RENDER_BACKENDS = ["vulkan", "skiavk", "opengl", "skiagl"];
// Scheduler yang selalu ditawarkan sebagai pilihan, digabung dengan hasil deteksi kernel device
const IOSCHED_CURATED = ["mq-deadline", "kyber", "bfq", "cfq", "adios"];
// Tiap toggle data-key dipetakan ke satu "section" apply (lihat
// buildApplyScript/sectionActive di bawah) - supaya nge-tap satu switch cuma
// menjalankan section miliknya sendiri, bukan menjalankan ULANG semua fitur
// lain yang tidak berubah. Ini akar perbaikan freeze pas "tekan on".
const KEY_SECTION = {
  FEATURE_RAM_MGMT: "ram",
  FEATURE_GRAPHICS: "graphics",
  FEATURE_LOGGING: "logging",
  FEATURE_GOVERNOR: "governor",
  FEATURE_ANIM: "anim",
  FEATURE_IOSCHED: "iosched",
  FEATURE_THERMAL: "thermal",
  FEATURE_RENDER: "render",
  FEATURE_DISPLAY: "display",
};
let ioSchedDevices = []; // { dev, current, available: [] }
let statsPollTimer = null; // interval id for refreshStats, paused during Apply
let statsInFlight = false; // guards against overlapping refreshStats calls piling up
let statsInFlightPromise = null; // the currently in-flight refreshStats() ksuExec call, if any.
// clearInterval(statsPollTimer) in applyAll() only stops the NEXT scheduled
// poll tick - it does nothing if a poll root shell was already sent a
// moment earlier and is still waiting on a callback. applyAll() awaits this
// promise first so it never starts its own (heavier) root shell while a
// poll is still running - two root shells racing over sysfs at once is what
// showed up as stutter, worse on 4GB RAM devices where forking a shell is
// already slower under memory pressure.
let applyInFlight = false; // guards against overlapping apply runs
// Section apa saja yang berubah selagi apply masih jalan -> cuma section itu
// yang di-apply ulang sekali lagi setelah yang sedang jalan selesai.
// pendingFull dipakai kalau section tidak diketahui -> apply ulang semuanya
// (fallback aman, misal dipanggil applyAll() tanpa argumen).
let pendingSections = new Set();
let pendingFull = false;

function parseConfig(text) {
  text.split("\n").forEach((line) => {
    const m = line.match(/^([A-Z_]+)=(.*)$/);
    if (m && m[1] in state) state[m[1]] = m[2].trim();
  });
}

async function loadConfig() {
  const res = await ksuExec(`cat ${CONFIG_PATH} 2>/dev/null`);
  if (res.stdout) parseConfig(res.stdout);
  renderState();
}

function renderState() {
  document.querySelectorAll(".toggle[data-key]").forEach((el) => {
    const key = el.dataset.key;
    el.checked = state[key] === "1";
  });
  document.querySelectorAll(".seg-btn[data-gov]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.gov === state.CPU_GOVERNOR);
  });
  document.querySelectorAll(".seg-btn[data-anim]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.anim === state.ANIM_SCALE);
  });
  document.querySelectorAll(".seg-btn[data-thermal]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.thermal === state.THERMAL_PROFILE);
  });
  document.querySelectorAll(".seg-btn[data-iosched]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.iosched === state.IO_SCHEDULER);
  });
  document.querySelectorAll(".seg-btn[data-render]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.render === state.RENDER_BACKEND);
  });
  updateGovernorLock();
}

// service.sh selalu jalanin section Governor SEBELUM section Thermal saat
// boot (lihat urutan di service.sh) - jadi kalau FEATURE_THERMAL=1, governor
// manual bakal ke-override sama governor bawaan profile thermal tiap
// reboot, walau FEATURE_GOVERNOR juga 1. Toggle & seg-btn Governor di-grey
// out selama Thermal Profile aktif biar tidak kelihatan seperti berlaku
// padahal ujung-ujungnya ditimpa.
function updateGovernorLock() {
  const card = document.getElementById("governor-card");
  const toggle = document.querySelector('.toggle[data-key="FEATURE_GOVERNOR"]');
  const note = document.getElementById("governor-lock-note");
  const locked = state.FEATURE_THERMAL === "1";
  if (card) card.classList.toggle("locked", locked);
  if (toggle) toggle.disabled = locked;
  if (note) note.hidden = !locked;
}

function buildConfigFile() {
  return `#!/system/bin/sh
# =====================================================
# OptimizationHyper - config.sh
# File ini diubah otomatis oleh Web UI module.
# =====================================================

# ----- Toggle fitur (1 = aktif, 0 = nonaktif) -----
FEATURE_RAM_MGMT=${state.FEATURE_RAM_MGMT}
FEATURE_GRAPHICS=${state.FEATURE_GRAPHICS}
FEATURE_LOGGING=${state.FEATURE_LOGGING}

# ----- CPU Governor -----
FEATURE_GOVERNOR=${state.FEATURE_GOVERNOR}
CPU_GOVERNOR=${state.CPU_GOVERNOR}

# ----- Skala Animasi -----
FEATURE_ANIM=${state.FEATURE_ANIM}
ANIM_SCALE=${state.ANIM_SCALE}

# ----- I/O Scheduler -----
FEATURE_IOSCHED=${state.FEATURE_IOSCHED}
IO_SCHEDULER=${state.IO_SCHEDULER}

# ----- Thermal Profile -----
FEATURE_THERMAL=${state.FEATURE_THERMAL}
THERMAL_PROFILE=${state.THERMAL_PROFILE}

# ----- Rendering -----
FEATURE_RENDER=${state.FEATURE_RENDER}
RENDER_BACKEND=${state.RENDER_BACKEND}

# ----- Resolusi Layar & DPI kustom -----
FEATURE_DISPLAY=${state.FEATURE_DISPLAY}
DISPLAY_RES=${state.DISPLAY_RES}
DISPLAY_DPI=${state.DISPLAY_DPI}
`;
}

function propBlock(flag, onCmds, offCmds) {
  return flag === "1" ? onCmds.join("\n") : offCmds.join("\n");
}

// section: undefined -> semua section aktif (fallback aman); string -> cuma
// section itu; array -> gabungan beberapa section yang lagi pending.
function sectionActive(name, section) {
  if (!section) return true;
  if (Array.isArray(section)) return section.includes(name);
  return section === name;
}

function buildApplyScript(section) {
  const lines = [];

  // write config file - selalu ditulis (murah: cuma cat+chmod) biar
  // config.sh yang dibaca service.sh & post-fs-data.sh pas boot tetap
  // lengkap, walau apply live-nya cuma menyentuh satu section.
  lines.push(`cat > ${CONFIG_PATH} << 'OHEOF'`);
  lines.push(buildConfigFile());
  lines.push("OHEOF");
  lines.push(`chmod 0755 ${CONFIG_PATH}`);

  // RAM management
  if (sectionActive("ram", section)) {
    lines.push(
      propBlock(
        state.FEATURE_RAM_MGMT,
        ["resetprop -n ro.sys.fw.bg_apps_limit 4"],
        ["resetprop --delete ro.sys.fw.bg_apps_limit"]
      )
    );
  }

  // Graphics
  if (sectionActive("graphics", section)) {
    lines.push(
      propBlock(
        state.FEATURE_GRAPHICS,
        [
          "resetprop -n persist.sys.use_dithering 0",
          "resetprop -n debug.egl.buffcount 4",
        ],
        [
          "resetprop --delete persist.sys.use_dithering",
          "resetprop --delete debug.egl.buffcount",
        ]
      )
    );
  }

  // Logging - blok TERBERAT (16 resetprop sekaligus). Dulu selalu ikut jalan
  // di setiap apply walau yang di-toggle fitur lain; sekarang cuma kalau
  // section yang berubah memang "logging".
  if (sectionActive("logging", section)) {
  lines.push(
    propBlock(
      state.FEATURE_LOGGING,
      [
        "resetprop -n debug.performance.tuning 1",
        "resetprop -n debug.mdpcomp.logs 0",
        "resetprop -n persist.vendor.dpm.loglevel 0",
        "resetprop -n debug.als.logs 0",
        "resetprop -n log.tag.stats_log 0",
        "resetprop -n persist.debug.trace 0",
        "resetprop -n persist.sys.loglevel 0",
        "resetprop -n ro.kernel.android.checkjni 0",
        "resetprop -n persist.vendor.sys.modem.logging.enable false",
        "resetprop -n persist.anr.dumpthr 0",
        "resetprop -n debug.sf.ddms 0",
        "resetprop -n persist.vendor.radio.snapshot_enabled 0",
        "resetprop -n ro.lmk.debug false",
        "resetprop -n persist.sys.lmk.reportkills false",
        "resetprop -n ro.logdumpd.enabled 0",
        "resetprop -n dalvik.vm.dexopt-flags m=y",
      ],
      [
        "resetprop --delete debug.performance.tuning",
        "resetprop --delete debug.mdpcomp.logs",
        "resetprop --delete persist.vendor.dpm.loglevel",
        "resetprop --delete debug.als.logs",
        "resetprop --delete log.tag.stats_log",
        "resetprop --delete persist.debug.trace",
        "resetprop --delete persist.sys.loglevel",
        "resetprop --delete ro.kernel.android.checkjni",
        "resetprop --delete persist.vendor.sys.modem.logging.enable",
        "resetprop --delete persist.anr.dumpthr",
        "resetprop --delete debug.sf.ddms",
        "resetprop --delete persist.vendor.radio.snapshot_enabled",
        "resetprop --delete ro.lmk.debug",
        "resetprop --delete persist.sys.lmk.reportkills",
        "resetprop --delete ro.logdumpd.enabled",
        "resetprop --delete dalvik.vm.dexopt-flags",
      ]
    )
  );
  }

  // CPU governor
  if (sectionActive("governor", section) && state.FEATURE_GOVERNOR === "1") {
    lines.push(
      `for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo ${state.CPU_GOVERNOR} > "$gov" 2>/dev/null; done`
    );
  }

  // Animation scale
  if (sectionActive("anim", section) && state.FEATURE_ANIM === "1") {
    lines.push(`settings put global window_animation_scale ${state.ANIM_SCALE}`);
    lines.push(`settings put global transition_animation_scale ${state.ANIM_SCALE}`);
    lines.push(`settings put global animator_duration_scale ${state.ANIM_SCALE}`);
  }

  // I/O Scheduler
  if (sectionActive("iosched", section) && state.FEATURE_IOSCHED === "1" && state.IO_SCHEDULER) {
    lines.push(`for q in /sys/block/*/queue/scheduler; do
  dev=$(echo "$q" | sed -E 's#.*/([^/]+)/queue/scheduler#\\1#')
  case "$dev" in zram*|loop*|ram*) continue ;; esac
  echo ${state.IO_SCHEDULER} > "$q" 2>/dev/null
done`);
  }

  // Thermal Profile - dulu SELALU jalan di setiap apply (fallback "balance"
  // walau fiturnya lagi off), padahal isinya loop tiap core CPU dengan
  // beberapa cat/grep/awk per core -> section terberat kedua setelah
  // Logging, dan dulu ikut ketembak walau yang di-toggle fitur lain sama
  // sekali. Sekarang cuma jalan kalau section-nya "thermal".
  if (sectionActive("thermal", section)) {
    lines.push(`[ -f "${FUNCTIONS_PATH}" ] && . "${FUNCTIONS_PATH}"`);
    if (state.FEATURE_THERMAL === "1") {
      lines.push(`oh_apply_thermal ${state.THERMAL_PROFILE}`);
    } else {
      lines.push(`oh_apply_thermal balance`);
    }
  }

  // Rendering backend (HWUI / RenderEngine)
  if (sectionActive("render", section) && state.FEATURE_RENDER === "1") {
    const r = state.RENDER_BACKEND;
    if (r === "vulkan") {
      lines.push("resetprop -n debug.hwui.renderer skiavk");
      lines.push("resetprop -n debug.renderengine.backend vulkan");
    } else if (r === "skiavk") {
      lines.push("resetprop -n debug.hwui.renderer skiavk");
      lines.push("resetprop -n debug.renderengine.backend skiaglthreaded");
    } else if (r === "opengl") {
      lines.push("resetprop -n debug.hwui.renderer opengl");
      lines.push("resetprop -n debug.renderengine.backend skiaglthreaded");
    } else {
      lines.push("resetprop -n debug.hwui.renderer skiagl");
      lines.push("resetprop -n debug.renderengine.backend skiaglthreaded");
    }
  }

  // Resolusi layar & DPI kustom
  if (sectionActive("display", section)) {
    if (state.FEATURE_DISPLAY === "1" && state.DISPLAY_RES) {
      lines.push(`wm size ${state.DISPLAY_RES} 2>/dev/null`);
    }
    if (state.FEATURE_DISPLAY === "1" && state.DISPLAY_DPI) {
      lines.push(`wm density ${state.DISPLAY_DPI} 2>/dev/null`);
    }
  }

  return lines.join("\n");
}

/* ---------- Live system status: CPU (Little/Big) / RAM ---------- */
const STATS_CMD = `
awk '/MemTotal/{print "MEM_TOTAL:"$2} /MemAvailable/{print "MEM_AVAIL:"$2}' /proc/meminfo
fps_ns=$(dumpsys SurfaceFlinger --latency 2>/dev/null | head -n1 | tr -d '[:space:]')
[ -n "$fps_ns" ] && echo "FPS_NS:$fps_ns"
for z in /sys/class/thermal/thermal_zone*; do
  ztype=$(cat "$z/type" 2>/dev/null)
  tval=$(cat "$z/temp" 2>/dev/null)
  [ -n "$tval" ] && echo "TZ:$ztype:$tval"
done
`.trim();

/* ---------- Info perangkat statis: kernel, model, android, io scheduler, display ---------- */
const STATIC_INFO_CMD = `
echo "KERNEL:$(uname -r 2>/dev/null)"
echo "MODEL:$(getprop ro.product.manufacturer 2>/dev/null) $(getprop ro.product.model 2>/dev/null)"
echo "ANDROID_VER:$(getprop ro.build.version.release 2>/dev/null) (SDK $(getprop ro.build.version.sdk 2>/dev/null))"
for q in /sys/block/*/queue/scheduler; do
  dev=$(echo "$q" | sed -E 's#.*/([^/]+)/queue/scheduler#\\1#')
  case "$dev" in zram*|loop*|ram*) continue ;; esac
  cur=$(cat "$q" 2>/dev/null)
  [ -n "$cur" ] && echo "IOSCHED:$dev:$cur"
done
wm size 2>/dev/null | grep -m1 "Physical size" | sed 's/^/WM_SIZE:/'
wm density 2>/dev/null | grep -m1 "Physical density" | sed 's/^/WM_DENSITY:/'
`.trim();

function parseIoSchedLine(line) {
  // format kernel: "noop deadline [cfq]" -> available + current (dalam kurung siku)
  const tokens = line.trim().split(/\s+/).filter(Boolean);
  const available = [];
  let current = "";
  tokens.forEach((tok) => {
    const m = tok.match(/^\[(.+)\]$/);
    if (m) {
      current = m[1];
      available.push(m[1]);
    } else {
      available.push(tok);
    }
  });
  return { available, current };
}

function renderIoSchedUI() {
  const seg = document.getElementById("iosched-seg");
  const desc = document.getElementById("iosched-dev-desc");
  if (!ioSchedDevices.length) {
    desc.textContent = t("iosched_none");
    return;
  }
  const primary = ioSchedDevices[0];
  desc.textContent = `/dev/${primary.dev}`;
  if (!state.IO_SCHEDULER) state.IO_SCHEDULER = primary.current;
  seg.innerHTML = "";
  const options = Array.from(new Set([...primary.available, ...IOSCHED_CURATED]));
  options.forEach((s) => {
    const btn = document.createElement("button");
    btn.className = "seg-btn";
    btn.dataset.iosched = s;
    btn.textContent = s;
    btn.addEventListener("click", () => {
      state.IO_SCHEDULER = s;
      renderState();
      applyAll("iosched");
    });
    seg.appendChild(btn);
  });
  renderState();
}

async function loadStaticInfo() {
  const res = await ksuExec(STATIC_INFO_CMD);
  if (!res.stdout) return;
  ioSchedDevices = [];
  let wmSize = "";
  let wmDensity = "";
  res.stdout.split("\n").forEach((line) => {
    if (line.startsWith("KERNEL:")) {
      document.getElementById("dev-kernel").textContent = line.slice(7).trim() || "-";
    } else if (line.startsWith("MODEL:")) {
      document.getElementById("dev-model").textContent = line.slice(6).trim() || "-";
    } else if (line.startsWith("ANDROID_VER:")) {
      document.getElementById("dev-android").textContent = line.slice(12).trim() || "-";
    } else if (line.startsWith("IOSCHED:")) {
      const rest = line.slice(8);
      const idx = rest.indexOf(":");
      if (idx > -1) {
        const dev = rest.slice(0, idx);
        const parsed = parseIoSchedLine(rest.slice(idx + 1));
        ioSchedDevices.push({ dev, ...parsed });
      }
    } else if (line.startsWith("WM_SIZE:")) {
      wmSize = line.slice(8).replace("Physical size:", "").trim();
    } else if (line.startsWith("WM_DENSITY:")) {
      wmDensity = line.slice(11).replace("Physical density:", "").trim();
    }
  });
  renderIoSchedUI();
  const curEl = document.getElementById("display-current");
  if (curEl) curEl.textContent = [wmSize, wmDensity ? `${wmDensity} dpi` : ""].filter(Boolean).join(" · ") || "-";
}

function renderTemp(tzLines) {
  const el = document.getElementById("dev-temp");
  if (!el) return;
  const zones = [];
  tzLines.forEach((line) => {
    const m = line.match(/^TZ:([^:]*):(\d+)$/);
    if (m) zones.push({ type: (m[1] || "").toLowerCase(), raw: Number(m[2]) });
  });
  if (!zones.length) return;
  const toC = (raw) => (raw > 1000 ? raw / 1000 : raw);
  let pick = zones.find((z) => /battery/.test(z.type));
  if (!pick) pick = zones.find((z) => /cpu|soc|tsens|apu|mtktscpu/.test(z.type));
  if (!pick) {
    const valid = zones.map((z) => toC(z.raw)).filter((c) => c > 0 && c < 120);
    if (valid.length) {
      const avg = valid.reduce((a, b) => a + b, 0) / valid.length;
      el.textContent = `${avg.toFixed(1)}°C`;
      return;
    }
  }
  if (pick) {
    const c = toC(pick.raw);
    el.textContent = `${c.toFixed(1)}°C`;
  }
}

function renderCpuTemp(tzLines) {
  const el = document.getElementById("dev-cpu-temp");
  if (!el) return;
  const zones = [];
  tzLines.forEach((line) => {
    const m = line.match(/^TZ:([^:]*):(\d+)$/);
    if (m) zones.push({ type: (m[1] || "").toLowerCase(), raw: Number(m[2]) });
  });
  if (!zones.length) return;
  const toC = (raw) => (raw > 1000 ? raw / 1000 : raw);
  const pick = zones.find((z) => /cpu|soc|tsens|apu|mtktscpu/.test(z.type));
  if (pick) {
    el.textContent = `${toC(pick.raw).toFixed(1)}°C`;
  }
}

function renderRam(totalKb, availKb) {
  const el = document.getElementById("ram-value");
  const bar = document.getElementById("ram-bar");
  if (!totalKb) return;
  const totalGb = totalKb / 1048576;
  const usedGb = (totalKb - (availKb || 0)) / 1048576;
  const pct = Math.min(100, Math.round((usedGb / totalGb) * 100));
  el.textContent = `${usedGb.toFixed(2)} / ${totalGb.toFixed(2)} GB`;
  bar.style.width = pct + "%";
}

function renderFps(nsRaw) {
  const el = document.getElementById("dev-fps");
  if (!el) return;
  const ns = Number(nsRaw);
  if (!ns || Number.isNaN(ns) || ns <= 0) {
    el.textContent = "-";
    return;
  }
  const hz = Math.round(1e9 / ns);
  el.textContent = hz > 0 && hz < 1000 ? `${hz} Hz` : "-";
}

async function refreshStats() {
  if (statsInFlight) return; // previous poll still running — don't stack another root shell on top of it
  statsInFlight = true;
  const pollPromise = ksuExec(STATS_CMD);
  statsInFlightPromise = pollPromise;
  let res;
  try {
    res = await pollPromise;
  } finally {
    statsInFlight = false;
    if (statsInFlightPromise === pollPromise) statsInFlightPromise = null;
  }
  if (res.errno !== 0 && !res.stdout) return;
  const lines = res.stdout.split("\n");
  let memTotal = null;
  let memAvail = null;
  let fpsNs = null;
  const tzLines = [];

  lines.forEach((line) => {
    let m;
    if ((m = line.match(/^MEM_TOTAL:(\d+)/))) memTotal = Number(m[1]);
    else if ((m = line.match(/^MEM_AVAIL:(\d+)/))) memAvail = Number(m[1]);
    else if ((m = line.match(/^FPS_NS:(\d+)/))) fpsNs = Number(m[1]);
    else if (line.startsWith("TZ:")) tzLines.push(line.trim());
  });

  if (memTotal) renderRam(memTotal, memAvail);
  if (fpsNs) renderFps(fpsNs);
  if (tzLines.length) {
    renderTemp(tzLines);
    renderCpuTemp(tzLines);
  }
}

/* ---------- UI wiring ---------- */
function setStatus(msg, type = "info") {
  const el = document.getElementById("status");
  el.textContent = msg;
  el.className = `status ${type}`;
}

async function checkBridge() {
  const res = await ksuExec("id");
  const bridgeEl = document.getElementById("bridge");
  if (res.errno === 0 && res.stdout.includes("uid=0")) {
    bridgeEl.textContent = t("bridge_ok");
    bridgeEl.className = "bridge ok";
    return true;
  } else {
    bridgeEl.textContent = t("bridge_fail");
    bridgeEl.className = "bridge fail";
    return false;
  }
}

// Tidak ada tombol Apply lagi — setiap toggle & pilihan langsung diterapkan
// lewat applyAll(section). applyInFlight + pendingSections/pendingFull
// mencegah beberapa toggle yang diubah cepat berturut-turut memicu banyak
// root shell bersamaan (itu akar masalah stutter yang sama seperti komentar
// di ksuExec di atas): kalau ada apply yang masih berjalan, perubahan
// berikutnya cukup ditandai "pending" dan akan di-apply ulang sekali lagi
// begitu yang sedang jalan selesai — bukan langsung nembak proses baru di
// atasnya.
//
// section menentukan bagian mana saja dari buildApplyScript() yang benar-benar
// dieksekusi (lihat sectionActive di atas). Sebelumnya applyAll() SELALU
// menjalankan ulang semua fitur (RAM, Graphics, Logging 16x resetprop,
// Governor, Anim, IOSched, Thermal, Render) walau yang diubah cuma satu
// switch — itu "script berat" yang bikin nge-tap satu toggle terasa
// nge-freeze di device RAM 4GB. Sekarang tiap toggle/pilihan cuma memicu
// section miliknya sendiri.
async function applyAll(section) {
  if (applyInFlight) {
    if (section) pendingSections.add(section);
    else pendingFull = true;
    return;
  }
  applyInFlight = true;
  setStatus(t("saving"), "info");
  // pause background polling during apply — running the (heavier) apply
  // script at the same time as the 3s stats poll was causing two root
  // shells to fight over cpufreq/sysfs at once, which is what showed up
  // as a stutter every time Apply was pressed
  if (statsPollTimer) {
    clearInterval(statsPollTimer);
    statsPollTimer = null;
  }
  // clearInterval above only stops the NEXT poll tick — a poll that started
  // just before this toggle was tapped may still be running. Wait for it so
  // the apply script never overlaps a poll root shell (see statsInFlightPromise
  // comment above).
  if (statsInFlightPromise) {
    await statsInFlightPromise;
  }
  const script = buildApplyScript(section);
  const res = await ksuExec(script, {}, 35000);
  if (res.errno === 0) {
    setStatus(t("saved"), "ok");
  } else {
    setStatus(`${t("save_fail")} (${res.stderr || res.errno})`, "fail");
  }
  statsPollTimer = setInterval(refreshStats, 3000);
  applyInFlight = false;
  if (pendingFull || pendingSections.size) {
    const nextSection = pendingFull ? undefined : Array.from(pendingSections);
    pendingFull = false;
    pendingSections = new Set();
    applyAll(nextSection);
  }
}

function initToggles() {
  document.querySelectorAll(".toggle[data-key]").forEach((el) => {
    el.addEventListener("change", () => {
      const key = el.dataset.key;
      state[key] = el.checked ? "1" : "0";
      updateGovernorLock();
      applyAll(KEY_SECTION[key]);
    });
  });
  document.querySelectorAll(".seg-btn[data-gov]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.CPU_GOVERNOR = btn.dataset.gov;
      renderState();
      applyAll("governor");
    });
  });
  document.querySelectorAll(".seg-btn[data-anim]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.ANIM_SCALE = btn.dataset.anim;
      renderState();
      applyAll("anim");
    });
  });
  document.querySelectorAll(".seg-btn[data-thermal]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.THERMAL_PROFILE = btn.dataset.thermal;
      renderState();
      applyAll("thermal");
    });
  });
  document.querySelectorAll(".seg-btn[data-render]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.RENDER_BACKEND = btn.dataset.render;
      renderState();
      applyAll("render");
    });
  });
  document.querySelectorAll(".theme-btn").forEach((btn) => {
    btn.addEventListener("click", () => setTheme(btn.dataset.theme));
  });
  document.getElementById("reload-btn").addEventListener("click", async () => {
    setStatus(t("loading"), "info");
    await loadConfig();
    setStatus("", "info");
  });
}

/* ---------- Resolusi Layar & DPI ---------- */
async function displayApply() {
  const statusEl = document.getElementById("display-status");
  const res = document.getElementById("display-res-input").value.trim();
  const dpi = document.getElementById("display-dpi-input").value.trim();
  if (!res && !dpi) return;
  statusEl.textContent = t("saving");
  statusEl.className = "status info";
  let cmd = "";
  if (res) cmd += `wm size ${res} 2>/dev/null\n`;
  if (dpi) cmd += `wm density ${dpi} 2>/dev/null\n`;
  const r = await ksuExec(cmd);
  if (r.errno === 0) {
    state.DISPLAY_RES = res;
    state.DISPLAY_DPI = dpi;
    state.FEATURE_DISPLAY = "1";
    statusEl.textContent = t("display_applied");
    statusEl.className = "status ok";
    await loadStaticInfo();
  } else {
    statusEl.textContent = `${t("save_fail")} (${r.stderr || r.errno})`;
    statusEl.className = "status fail";
  }
}

async function displayReset() {
  const statusEl = document.getElementById("display-status");
  statusEl.textContent = t("saving");
  statusEl.className = "status info";
  const r = await ksuExec("wm size reset 2>/dev/null\nwm density reset 2>/dev/null");
  if (r.errno === 0) {
    state.DISPLAY_RES = "";
    state.DISPLAY_DPI = "";
    state.FEATURE_DISPLAY = "0";
    document.getElementById("display-res-input").value = "";
    document.getElementById("display-dpi-input").value = "";
    statusEl.textContent = t("display_applied");
    statusEl.className = "status ok";
    await loadStaticInfo();
  } else {
    statusEl.textContent = `${t("save_fail")} (${r.stderr || r.errno})`;
    statusEl.className = "status fail";
  }
}

function initExtraFeatures() {
  // Tidak ada tombol Apply lagi untuk resolusi/DPI — diterapkan otomatis saat
  // user keluar dari field (blur) atau menekan Enter, bukan di setiap huruf
  // yang diketik (supaya "wm size/density" tidak nembak layar tiap keystroke).
  const resInput = document.getElementById("display-res-input");
  const dpiInput = document.getElementById("display-dpi-input");
  [resInput, dpiInput].forEach((input) => {
    input.addEventListener("blur", displayApply);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") input.blur();
    });
  });
  document.getElementById("display-reset-btn").addEventListener("click", displayReset);
}

async function init() {
  applyTheme();
  applyI18n();
  initToggles();
  initExtraFeatures();
  setStatus(t("loading"), "info");
  // checkBridge + loadConfig don't depend on each other — run them together
  // instead of one after another, since every ksuExec spawns a root shell
  // and doing that serially is what made the panel feel sluggish on open.
  const [bridgeOk] = await Promise.all([checkBridge(), loadConfig()]);
  applyI18n();
  setStatus("", "info");
  if (bridgeOk) {
    await loadStaticInfo();
    refreshStats();
    statsPollTimer = setInterval(refreshStats, 3000);
  }
}

document.addEventListener("DOMContentLoaded", init);
