#!/system/bin/sh
# OptimizationHyper by Yannnbarubelajar
# Jalan setelah boot selesai (late_start service)

MODDIR=${0%/*}
CONFIG="$MODDIR/config.sh"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

sleep 5

[ -f "$CONFIG" ] && . "$CONFIG"

# ===== CPU Governor =====
if [ "$FEATURE_GOVERNOR" = "1" ] && [ -n "$CPU_GOVERNOR" ]; then
    for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo "$CPU_GOVERNOR" > "$gov" 2>/dev/null
    done
fi

# ===== Animation Scale =====
if [ "$FEATURE_ANIM" = "1" ] && [ -n "$ANIM_SCALE" ]; then
    settings put global window_animation_scale "$ANIM_SCALE"
    settings put global transition_animation_scale "$ANIM_SCALE"
    settings put global animator_duration_scale "$ANIM_SCALE"
fi

# ===== OptimizationHyper: I/O Scheduler =====
if [ "$FEATURE_IOSCHED" = "1" ] && [ -n "$IO_SCHEDULER" ]; then
    for q in /sys/block/*/queue/scheduler; do
        dev=$(echo "$q" | sed -E 's#.*/([^/]+)/queue/scheduler#\1#')
        case "$dev" in
            zram*|loop*|ram*) continue ;;
        esac
        echo "$IO_SCHEDULER" > "$q" 2>/dev/null
    done
fi

# ===== OptimizationHyper: Thermal Profile =====
# oh_apply_thermal() sekarang di oh_functions.sh (dipakai bareng dengan
# instant-apply Web UI di script.js, biar cuma ada 1 kopi logikanya).
[ -f "$MODDIR/oh_functions.sh" ] && . "$MODDIR/oh_functions.sh"
if [ "$FEATURE_THERMAL" = "1" ] && [ -n "$THERMAL_PROFILE" ]; then
    oh_apply_thermal "$THERMAL_PROFILE"
fi

# ===== OptimizationHyper: Resolusi Layar & DPI kustom =====
if [ "$FEATURE_DISPLAY" = "1" ]; then
    [ -n "$DISPLAY_RES" ] && wm size "$DISPLAY_RES" 2>/dev/null
    [ -n "$DISPLAY_DPI" ] && wm density "$DISPLAY_DPI" 2>/dev/null
fi

# ===== Buka Telegram sekali saja setelah instalasi pertama =====
MARKER="$MODDIR/.open_telegram"
if [ -f "$MARKER" ]; then
    # Tunggu sampai layar kebuka (kalau device masih di keyguard, intent activity
    # sering ditolak/di-antre oleh sistem)
    i=0
    while [ "$i" -lt 30 ]; do
        locked="$(dumpsys window 2>/dev/null | grep -m1 -o 'mDreamingLockscreen=true\|isStatusBarKeyguard=true')"
        [ -z "$locked" ] && break
        sleep 2
        i=$((i + 1))
    done
    sleep 2

    TG_URL="https://t.me/aboutYannz"
    ok=0
    j=0
    while [ "$j" -lt 3 ] && [ "$ok" -eq 0 ]; do
        am start --user 0 -a android.intent.action.VIEW -f 0x10000000 -d "$TG_URL" > /dev/null 2>&1
        # Anggap berhasil kalau perintah am tidak error
        [ "$?" -eq 0 ] && ok=1
        sleep 3
        j=$((j + 1))
    done

    rm -f "$MARKER"
fi
