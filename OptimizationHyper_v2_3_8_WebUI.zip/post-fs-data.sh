#!/system/bin/sh
# OptimizationHyper by Yannnbarubelajar
# Terapkan resetprop sesuai toggle fitur di config.sh (diatur lewat Web UI)

MODDIR=${0%/*}
CONFIG="$MODDIR/config.sh"

[ -f "$CONFIG" ] && . "$CONFIG"

# ===== RAM Management =====
if [ "$FEATURE_RAM_MGMT" = "1" ]; then
    resetprop -n ro.sys.fw.bg_apps_limit 4
fi

# ===== Graphics & Display =====
if [ "$FEATURE_GRAPHICS" = "1" ]; then
    resetprop -n persist.sys.use_dithering 0
    resetprop -n debug.egl.buffcount 4
fi

# ===== Disable Logging & Debugging =====
if [ "$FEATURE_LOGGING" = "1" ]; then
    resetprop -n debug.performance.tuning 1
    resetprop -n debug.mdpcomp.logs 0
    resetprop -n persist.vendor.dpm.loglevel 0
    resetprop -n debug.als.logs 0
    resetprop -n log.tag.stats_log 0
    resetprop -n persist.debug.trace 0
    resetprop -n persist.sys.loglevel 0
    resetprop -n ro.kernel.android.checkjni 0
    resetprop -n persist.vendor.sys.modem.logging.enable false
    resetprop -n persist.anr.dumpthr 0
    resetprop -n debug.sf.ddms 0
    resetprop -n persist.vendor.radio.snapshot_enabled 0
    resetprop -n ro.lmk.debug false
    resetprop -n persist.sys.lmk.reportkills false
    resetprop -n ro.logdumpd.enabled 0
    resetprop -n dalvik.vm.dexopt-flags m=y
fi

# ===== OptimizationHyper: Rendering backend (HWUI / RenderEngine) =====
# Pilihan: vulkan | skiavk | opengl | skiagl
if [ "$FEATURE_RENDER" = "1" ] && [ -n "$RENDER_BACKEND" ]; then
    case "$RENDER_BACKEND" in
        vulkan)
            resetprop -n debug.hwui.renderer skiavk
            resetprop -n debug.renderengine.backend vulkan
            ;;
        skiavk)
            resetprop -n debug.hwui.renderer skiavk
            resetprop -n debug.renderengine.backend skiaglthreaded
            ;;
        opengl)
            resetprop -n debug.hwui.renderer opengl
            resetprop -n debug.renderengine.backend skiaglthreaded
            ;;
        skiagl|*)
            resetprop -n debug.hwui.renderer skiagl
            resetprop -n debug.renderengine.backend skiaglthreaded
            ;;
    esac
fi
