ui_print "======================================="
ui_print "  OptimizationHyper v2.3.8 - by Yannnbarubelajar"
ui_print "======================================="
ui_print "- RAM management (bg apps limit)"
ui_print "- Graphics & Display (dithering, egl buffcount)"
ui_print "- Logging & debug disabled"
ui_print "- CPU Governor"
ui_print "- Animation scale"
ui_print "- I/O Scheduler (mq-deadline/kyber/bfq/cfq/adios)"
ui_print "- Rendering backend (vulkan/skiavk/opengl/skiagl)"
ui_print "- Thermal profile"
ui_print "- Please reboot your device to apply this module"
ui_print "======================================="

OLD_CONFIG="/data/adb/modules/$MODID/config.sh"
if [ -f "$OLD_CONFIG" ]; then
    ui_print "- Konfigurasi lama ditemukan, dipertahankan."
    cp -af "$OLD_CONFIG" "$MODPATH/config.sh"
else
    touch "$MODPATH/.open_telegram"
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/oh_functions.sh 0 0 0755
set_perm $MODPATH/config.sh 0 0 0755
set_perm_recursive $MODPATH/webroot 0 0 0755 0644
