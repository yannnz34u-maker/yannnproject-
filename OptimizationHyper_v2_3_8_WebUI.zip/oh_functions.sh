#!/system/bin/sh
# OptimizationHyper - oh_functions.sh
# Fungsi shell yang dipakai BARENG oleh service.sh (apply saat boot) dan
# instant-apply Web UI (lihat buildApplyScript di webroot/script.js).
# Disatukan di sini supaya logikanya cuma ada SATU kopi - sebelumnya
# oh_apply_thermal() didefinisikan terpisah di 2 tempat (service.sh &
# script.js) yang gampang ketinggalan sinkron kalau salah satu diedit tapi
# yang satunya lupa. Itu penyebab kasus profile "balance" tidak pernah
# ke-underclock: case "balance" tidak pernah ditambahkan di salah satu/kedua
# kopi, jadi selalu jatuh ke default (pct=100 / tidak dibatasi).

# ===== Thermal Profile =====
oh_apply_thermal() {
    profile="$1"
    little_target=""
    big_target=""
    case "$profile" in
        powersave) pct=60; gov="powersave" ;;
        performance) pct=100; gov="performance" ;;
        balance) pct=""; gov="schedutil"; little_target=1400000; big_target=1800000 ;;
        little_performance) pct=""; gov="performance"; little_target=1800000; big_target=2200000 ;;
        *) pct=100; gov="schedutil" ;;
    esac
    # Balance & Little Performance nembak MHz literal per cluster (bukan
    # persentase dari cpuinfo_max_freq device), jadi tidak bisa pakai pct.
    # little_min dipakai untuk kenalin cluster Little: core dengan
    # cpuinfo_max_freq PALING RENDAH -> dianggap Little, sisanya Big.
    # Kalau device cuma 1 cluster, semua core kebagian little_target.
    little_min=""
    if [ -n "$little_target" ]; then
        for f in /sys/devices/system/cpu/cpu*/cpufreq; do
            mf=$(cat "$f/cpuinfo_max_freq" 2>/dev/null)
            if [ -n "$mf" ]; then
                if [ -z "$little_min" ] || [ "$mf" -lt "$little_min" ]; then
                    little_min="$mf"
                fi
            fi
        done
    fi
    for f in /sys/devices/system/cpu/cpu*/cpufreq; do
        target=""
        maxf=$(cat "$f/cpuinfo_max_freq" 2>/dev/null)
        avail="$f/scaling_available_governors"
        setgov="$gov"
        if [ -f "$avail" ] && ! grep -qw "$gov" "$avail"; then
            case "$gov" in
                powersave) grep -qw conservative "$avail" 2>/dev/null && setgov=conservative || setgov=$(awk '{print $1}' "$avail") ;;
                *) setgov=$(awk '{print $1}' "$avail") ;;
            esac
        fi
        if [ -n "$little_target" ]; then
            if [ "$maxf" = "$little_min" ]; then
                target=$little_target
            else
                target=$big_target
            fi
        elif [ -n "$maxf" ]; then
            target=$((maxf * pct / 100))
        fi
        [ -n "$target" ] && echo "$target" > "$f/scaling_max_freq" 2>/dev/null
        [ -n "$setgov" ] && echo "$setgov" > "$f/scaling_governor" 2>/dev/null
    done
}
