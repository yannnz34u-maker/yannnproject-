#!/system/bin/sh
# =====================================================
# OptimizationHyper - config.sh
# File ini diubah otomatis oleh Web UI module.
# Jangan hapus baris apapun, cukup ubah nilainya (0/1
# untuk toggle, atau teks untuk governor/animasi).
# =====================================================

# ----- Toggle fitur (1 = aktif, 0 = nonaktif) -----
FEATURE_RAM_MGMT=1
FEATURE_GRAPHICS=1
FEATURE_LOGGING=1

# ----- CPU Governor -----
# Pilihan: schedutil | performance | powersave | conservative | sugov_ext
FEATURE_GOVERNOR=0
CPU_GOVERNOR=schedutil

# ----- Skala Animasi -----
# Pilihan: 0.0 | 0.5 | 1.0
FEATURE_ANIM=0
ANIM_SCALE=1.0

# ----- I/O Scheduler -----
# Pilihan umum: mq-deadline | kyber | bfq | cfq | adios (+ apa pun yang didukung kernel device)
FEATURE_IOSCHED=0
IO_SCHEDULER=

# ----- Thermal Profile -----
# Pilihan: powersave | balance | performance
FEATURE_THERMAL=0
THERMAL_PROFILE=balance

# ----- Rendering (HWUI / RenderEngine backend) -----
# Pilihan: vulkan | skiavk | opengl | skiagl
FEATURE_RENDER=0
RENDER_BACKEND=skiagl

# ----- Resolusi Layar & DPI kustom -----
FEATURE_DISPLAY=0
DISPLAY_RES=
DISPLAY_DPI=
